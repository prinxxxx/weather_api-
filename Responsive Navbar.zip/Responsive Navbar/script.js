let bar = document.getElementById("bar")
let nav = document.querySelector("#nav-contents")
bar.addEventListener("click",()=>{
     nav.style.visibility="visible"
})